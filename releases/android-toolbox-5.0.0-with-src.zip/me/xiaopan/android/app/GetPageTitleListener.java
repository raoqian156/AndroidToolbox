package me.xiaopan.android.app;

public interface GetPageTitleListener {
	public CharSequence onGetPageTitle(int position);
}
